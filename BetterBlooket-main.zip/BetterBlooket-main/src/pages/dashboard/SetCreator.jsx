import { useEffect } from "react";
import Sidebar from "./SideBar";
function SetCreator() {
    return (<>
        <Sidebar>
            set creator
        </Sidebar>
    </>);
}
export default SetCreator;