import { useEffect } from "react";
import Sidebar from "./SideBar";
function Discover() {
    useEffect(() => {
        // fetch Discover
    }, []);
    return (<>
        <Sidebar>
            Discover
        </Sidebar>
    </>);
}
export default Discover;