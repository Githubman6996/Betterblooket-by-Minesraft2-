import { useEffect } from "react";
import Sidebar from "./SideBar";
function Sets() {
    useEffect(() => {
        // fetch Sets
    }, []);
    return (<>
        <Sidebar>
            Sets
        </Sidebar>
    </>);
}
export default Sets;