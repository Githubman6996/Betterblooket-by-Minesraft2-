# BetterBlooket
A Blooket remake using Tauri.
